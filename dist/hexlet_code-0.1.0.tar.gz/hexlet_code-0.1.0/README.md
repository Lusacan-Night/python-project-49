Brain games
---
### Hexlet tests and linter status:
[![Actions Status](https://github.com/Lusacan-Night/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Lusacan-Night/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/99db5be5d5f9f3d65066/maintainability)](https://codeclimate.com/github/Lusacan-Night/python-project-49/maintainability)

Brain games is a collection of 5 math mini-games, where you need to correctly answer on 3 questions.
- brain-even demo https://asciinema.org/a/MdxtmbtlnZ6NQ8Ak8S1umTuWY
- brain-calc demo https://asciinema.org/a/rKVYy5BtXFVEBxtirRVaVOBN5
- brain-gcd demo https://asciinema.org/a/adAvE2DUpfTKeJHiMWpMSTaur
- brain-progression demo https://asciinema.org/a/cI4MBROZbWRblvcZs3yBTRn44
- brain-prime demo https://asciinema.org/a/bjZfAA2pSjVH9v8diuLqlTec8