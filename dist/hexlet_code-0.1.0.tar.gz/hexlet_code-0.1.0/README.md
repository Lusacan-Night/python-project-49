### Hexlet tests and linter status:
[![Actions Status](https://github.com/Lusacan-Night/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Lusacan-Night/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/99db5be5d5f9f3d65066/maintainability)](https://codeclimate.com/github/Lusacan-Night/python-project-49/maintainability)

- brain-even demo https://asciinema.org/a/MdxtmbtlnZ6NQ8Ak8S1umTuWY
- brain-calc demo https://asciinema.org/a/rKVYy5BtXFVEBxtirRVaVOBN5
- brain-gcd demo https://asciinema.org/a/adAvE2DUpfTKeJHiMWpMSTaur
- brain-progression https://asciinema.org/a/cI4MBROZbWRblvcZs3yBTRn44