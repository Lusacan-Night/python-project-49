#!/usr/bin/env python3

from brain_games.games.games import game_loop


def main():
    game_loop('prime')


if __name__ == '__main__':
    main()
